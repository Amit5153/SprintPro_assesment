import React from 'react'
import './App.css'
import Calander from './components/Calander'

function App() {
 
  return (
    <>
       
      <Calander/>
     
    </>
  )
}

export default App
